package com.kitty.myapp;

import android.content.res.AssetManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class NotificationsFragment extends Fragment {
    AssetManager assetManager;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        View view = inflater.inflate(R.layout.fragment_notifications, container, false);

        AssetManager assetManager = getActivity().getAssets();
            InputStream in = null;
            OutputStream out = null;
            try {
                in = assetManager.open( "blanksheet.xlsx");
                File outFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath() +"/", "blanksheet.xlsx");
                out = new FileOutputStream(outFile);
                copyFile(in, out);
                in.close();
                in = null;
                out.flush();
                out.close();
                out = null;
            } catch(IOException e) {
                Log.e("tag", "Failed to copy asset file: ", e);
            }
        FileInputStream fi = null;
        try {
            fi = new FileInputStream("blanksheet.xlsx");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        Workbook wb = null;
        try {
            wb = new XSSFWorkbook(fi);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Cell c = wb.getSheetAt(0).getRow(14).getCell(4);
        c.setCellValue("xyz");
        Toast.makeText(getActivity(), "second Fragment", Toast.LENGTH_LONG).show();
        FileOutputStream fileOut = null;
        try {
            fileOut = new FileOutputStream("data/text1.xlsx");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            wb.write(fileOut);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            fileOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return view;
    }

    private void copyFile(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[1024];
        int read;
        while((read = in.read(buffer)) != -1){
            out.write(buffer, 0, read);
        }
    }
}
